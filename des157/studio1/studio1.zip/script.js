(function() {
    'use strict'
    console.log("Reading JS");

    const mlForm = document.querySelector("#mlForm");
    
    const foodItem = document.querySelectorAll("input[type=radio");
    for(const item of foodItem) {
        item.onclick = function(e) {
            e.preventDefault();

            for(const option of foodItem) {
                if(item == option) {
                    item.className = "selected";
                } else {
                    item.classList.remove("selected");
                }
            }
        }
    }
    
    function makeMadLib(words) {
        const mlOutput = document.querySelector("#mlOutput");

        const mlText = `Hi ${words[0]} and ${words[1]}, adjective ${words[2]} and verb ${words[3]}`;

        mlOutput.innerHTML = mlText;
    }

    function processForm(formData) {
        const words = [];

        for(const field of formData) {
            words.push(field.value);
            field.value = "";
        }

        makeMadLib(words);
    }

    mlForm.onsubmit = function(e) {
        e.preventDefault();

        const formData = document.querySelectorAll("input[type=text");
        processForm(formData);
    }

} ());